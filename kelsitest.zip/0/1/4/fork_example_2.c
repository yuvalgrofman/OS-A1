#include <stdio.h>

int main() {
    printf("fork_example_2.c\n");
}