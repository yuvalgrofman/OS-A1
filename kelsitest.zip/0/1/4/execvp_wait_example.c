#include <stdio.h>

int main() {
    printf("execvp_wait_example.c\n");
}