#include <stdio.h>

int main() {
    printf("execl_example.c\n");
}