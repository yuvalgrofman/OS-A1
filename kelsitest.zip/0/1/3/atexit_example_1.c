#include <stdio.h>

int main() {
    printf("atexit_example_1.c\n");
}