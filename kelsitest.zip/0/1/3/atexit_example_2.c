#include <stdio.h>

int main() {
    printf("atexit_example_2.c\n");
}