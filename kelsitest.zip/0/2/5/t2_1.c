#include <stdio.h>

int main() {
    printf("t2_1.c\n");
}