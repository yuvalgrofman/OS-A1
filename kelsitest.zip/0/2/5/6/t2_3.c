#include <stdio.h>

int main() {
    printf("t2_3.c\n");
}