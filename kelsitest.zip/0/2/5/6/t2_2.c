#include <stdio.h>

int main() {
    printf("t2_2.c\n");
}