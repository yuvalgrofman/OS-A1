#include <stdio.h>

int main() {
    printf("waitpid_exmaple.c\n");
}