#include <stdio.h>

int main() {
    printf("wait_example_1.c\n");
}