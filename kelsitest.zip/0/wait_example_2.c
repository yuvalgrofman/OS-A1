#include <stdio.h>

int main() {
    printf("wait_example_2.c\n");
}